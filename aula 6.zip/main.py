# print()
# cidade =  ' guarulhos'
# print (cidade,"\n")
# frang = list(cidade )
# # print(frang)

# tr =  tuple(frag)
# print (tr)



# numero = range(1,11,1)
# print(numero)


# n = range(1,3)
# print(n)


# lista =  {10,6,56} 
# soma =sum(lista)
# print( "a soma de tudo é:",soma)




# min(), max(): Encontra o valor mínimo e máximo em uma sequência.


# listao= ['a','s','d','r','y']
# list = [56,65,68,67,78,14]
# organize = sorted(list+listao)
# print 




# minha_lista = [1, 2, 3, 4, 5]
# print(minha_lista)  # Isso imprimirá 














# frutas = ['maçâ','banana','uva','cereja' , False]  
# frutas. append('melao')
# print(frutas)
# frutas.append(12)
# print(frutas)
         
         
         
         
         
         
         
         # ]



# for i  in  range (0,51): 
#   print (i)

# for n  in range(1,13):
#   print (n)







# Aula 3

# len = comprimento (quantidade)

# nome_da_cidade = 'Guarulhos'
# comprimento = len(nome_da_cidade)
# print(comprimento)

# dia_da_semana = 'sabado'
# print(len(dia_da_semana))

# x = 4
# print(type(x))

# x = 'terra'
# dado = x
# print(type(dado))

# z = '45'
# n = float(z)
# print(int(z))
# print(n+5)

# cidade = 'Guarulhos'
# print(cidade, '\n')
# frag = list(cidade)
# print(frag)

# tr = tuple(frag)
# print(tr)

# numero = range(1,11,2)
# print(numero)

# n = range (1,3)
# print(n)

# lista = [1,6,812,0,45]
# soma = sum(lista)
# print('a soma de tudo é', soma)

# lista = [100,36,145,1]
# maxi = max(lista)
# print(maxi)

# lista = [100,36,145,1]
# mini = min(lista)
# print(mini)

# lista = [56,566,7878,15,1,0,89,10]
# organize = sorted(lista)
# print(organize)

# lista = ['a','e','r','g','b','y','t','j']
# organize = sorted(lista)
# print(organize)

# for i in range(1,51):
#     print(i)

# for n in range(1,13,2):
#   print(n)





# :exercio pagina 5 


# for i in range(5,55,5):
# print(i)
# list = range(5,50,5)
# soma = sum(list)
# print ("a soma de tudo e", soma)

    































# Exercício 3: Escreva um programa que use a função type() para verificar o tipo de uma variável.





# x = 4
# print(type(x))




  
# Exercício 4: Escreva um programa que use a função print() para imprimir uma mensagem de saudação personalizada, incluindo o nome do usuário.


# nome = input("quem fala  ")
# print ("ola", nome)


# **Exercício 5:** Escreva um programa que use a função `range()` para gerar os números ímpares de 1 a 10 e, em seguida, calcule e imprima a média desses números.





# dicionario 



# dados = {'nome': 'julio' , 'idade': 18,  'endereco':'rua 10'}

# for i1,i2 in dados.items():
#   print (f'{i1} : {i2}')




  
  


























# palavra =  'python'
# for  letra in palavra:
#   print(letra)
  



# numeros = range(1, 10) 










# lista = [ 'maçã', 'banana', 'cereja' ,'uva'3]


# for i in lista:
#  print(i[2])




























# Exercício 2: Acesse e imprima o terceiro elemento da lista numeros.


# minha_lista = [1, 2, 3, 4, 5]
# primeiro_elemento = minha_lista[2]
# print(primeiro_elemento)  # Isso imprimirá 3







# Exercício 3: Adicione o número 6 à lista numeros e imprima a lista atualizada

# minha_lista = [1, 2, 3, 4, 5]
# minha_lista.append(6)
# print(minha_lista)  # Agora a lista conterá [1, 2, 3, 4, 5, 6]


# **Exercício 4:** Remova o número 3 da lista `numeros` e imprima a lista resultante.


# minha_lista = [1, 2, 3, 4, 5]
# minha_lista.remove(3)  # Isso removerá o elemento 3 da lista
# print(minha_lista)






# Exercício 5: Crie uma lista chamada frutas contendo três nomes de frutas diferentes. Em seguida, concatene essa lista com a lista numeros e imprima o resultado.

# minha_lista = [1, 2, 3, 4]
# frutas = ("manga","mamao","banana","abacate")
# print("os numeros sao",minha_lista, "as frutas sao",frutas)

  



# Exercício 6: Use um loop for para percorrer e imprimir todos os elementos da lista frutas.


# frutas = ("manga","mamao","banana","abacate")
# for elemento in frutas:
#     print(elemento)
  


# Exercício 7: Verifique se o número 5 está presente na lista numeros e imprima uma mensagem informando se ele está na lista ou não.
# minha_lista = [1, 2, 3, 4,5] 
# (tira ou colocar numero 5 pra ver resoltado do exmplo)
# if 5 in minha_lista: 
#       print ('existe o numero na lista')
# else:  
#   print("nao exsite numero na lista")
  




